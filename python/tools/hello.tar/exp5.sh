#!/usr/bin/expect 
set username [lindex $argv 0]
set ip [lindex $argv 1]
#set timeout 30

spawn ssh -l $username $ip 
expect "*yes*"
send "yes\r"
expect "*password*"
send "abcd1234\r"
interact
~
