#!/usr/bin/expect
set timeout 30
spawn ssh -l "$0" 192.168.179.132
#expect "*yes*"
#send "yes\r" 
expect "*password*"
send "abcd1234\r"
interact
