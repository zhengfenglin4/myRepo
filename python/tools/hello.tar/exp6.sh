#!/usr/bin/expect
set passwd "mypasswd"
set timeout 60
send "$passwd\n"
if {$argc != 1}{
	send "useage ./exp6.sh \$newaccount\n"
	exit
}
set user [lindex $argv [expr $argc-1]]
spawn sudo useradd -s /bin/bash -g mygroup -m $user
expect {
	"assword"{
		send_user "sudo now\n"
		send "$passwd\n"
		exp_coutinue
	}
	eof{
		send_user "eof\n"
	}


}
