#!/usr/bin/expect
set timeout 30
spawn sudo fdisk -l
expect "*password*"
send "abcd1234\r"
interact
