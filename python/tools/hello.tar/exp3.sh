#!/usr/bin/expect
set timeout 30
#set user[lindex $argv 0]
spawn bash $user
#expect "]:" 
#expect "*password*"
#send "abcd1234\r"
#interact
